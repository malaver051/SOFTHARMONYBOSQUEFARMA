package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Optional;
import co.edu.unbosque.model.Inventario;
import co.edu.unbosque.model.Turno;
import co.edu.unbosque.model.persistence.FuncionarioDAO;
import co.edu.unbosque.model.persistence.InventarioDAO;
import co.edu.unbosque.model.persistence.TurnoDAO;

public class PanelExpendio extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTextField cedulaField;
    private JTextField cantidadField;
    private JTextArea displayArea;
    private JButton buscarButton;
    private JButton expenderButton;
    private JButton volverButton; 
    public static final String BUSCAR = "Buscar";
    public static final String EXPENDER = "Expender";
    public static final String VOLVER = "Volver"; 
    private JLabel imagen;

    public PanelExpendio(ActionListener listener) {
        new FuncionarioDAO();
        new InventarioDAO();
        new TurnoDAO();

        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 245));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        
        JPanel inputPanel = new JPanel(new GridLayout(3, 3, 10, 10));
        inputPanel.setOpaque(false); 

        
        JLabel cedulaLabel = new JLabel("Cédula del Cliente:");
        cedulaLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        cedulaField = new JTextField(15);
        cedulaField.setFont(new Font("Arial", Font.PLAIN, 14));

        buscarButton = createButton("Buscar Orden", BUSCAR, listener, new Color(0, 123, 255));
        expenderButton = createButton("Expender Medicamentos", EXPENDER, listener, new Color(40, 167, 69));
        volverButton = createButton("Volver", VOLVER, listener, new Color(255, 72, 72)); // Rojo para "Volver"

        JLabel cantidadLabel = new JLabel("Cantidad a expender:");
        cantidadLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        cantidadField = new JTextField(5);
        cantidadField.setFont(new Font("Arial", Font.PLAIN, 14));

        
        inputPanel.add(cedulaLabel);
        inputPanel.add(cedulaField);
        inputPanel.add(buscarButton);
        inputPanel.add(cantidadLabel);
        inputPanel.add(cantidadField);
        inputPanel.add(expenderButton);
        inputPanel.add(volverButton);

        
        displayArea = new JTextArea(15, 40);
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        displayArea.setLineWrap(true);
        displayArea.setWrapStyleWord(true);
        displayArea.setBackground(new Color(240, 240, 240));
        displayArea.setForeground(new Color(50, 50, 50));
        displayArea.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));

       
        JPanel displayPanel = new JPanel();
        displayPanel.setBackground(new Color(245, 245, 245));
        displayPanel.add(new JScrollPane(displayArea));

        add(inputPanel, BorderLayout.NORTH);
        add(displayPanel, BorderLayout.CENTER);

        
        imagen = new JLabel();
        imagen.setIcon(new ImageIcon("C:\\Users\\adminpc\\Desktop\\unbosque.edu\\SOTHARMONYBOSQUEFARMA.zip_expanded\\SOFTHARMONYBOSQUEFARMA\\src\\imagenes\\fondoExpendioMedicamentos.png"));
        imagen.setLayout(new BorderLayout());
        imagen.setBounds(0, 0, getWidth(), getHeight());
        add(imagen, BorderLayout.SOUTH);
    }

    
    private JButton createButton(String text, String actionCommand, ActionListener listener, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setActionCommand(actionCommand);
        button.addActionListener(listener);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(backgroundColor);
        button.setForeground(Color.WHITE);
        button.setPreferredSize(new Dimension(150, 40));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        return button;
    }

    
    public String getCedula() {
        String cedula = cedulaField.getText().trim();
        if (cedula.isEmpty()) {
            displayArea.append("Por favor, ingrese una cédula válida.\n");
        }
        return cedula;
    }

    
    public int getCantidad() {
        try {
            return Integer.parseInt(cantidadField.getText());
        } catch (NumberFormatException e) {
            displayArea.append("Por favor, ingrese un número válido para la cantidad.\n");
            return -1; 
        }
    }

   
    public void mostrarOrden(Optional<Turno> turnoOpt, Optional<Inventario> inventarioOpt) {
        displayArea.setText("");
        if (turnoOpt.isPresent() && inventarioOpt.isPresent()) {
            Turno turno = turnoOpt.get();
            Inventario inventario = inventarioOpt.get();
            displayArea.append("Turno: " + turno.getNumeroTurno() + "\n");
            displayArea.append("Documento del Paciente: " + turno.getDocumentoPaciente() + "\n");
            displayArea.append("Estado: " + turno.getEstado() + "\n");
            displayArea.append("Medicamento: " + inventario.getNombreMedicamento() + "\n");
            displayArea.append("Cantidad Disponible: " + inventario.getCantidad() + "\n");
        } else {
            displayArea.append("No se encontró la orden para la cédula proporcionada.");
        }
    }

    
    public void expenderMedicamentos(Optional<Turno> turnoOpt, Optional<Inventario> inventarioOpt, int cantidad) {
        displayArea.setText("");

        
        if (cantidad <= 0) {
            displayArea.append("Por favor, ingrese una cantidad válida para expender.\n");
            return;
        }
        if (turnoOpt.isPresent() && inventarioOpt.isPresent()) {
            Turno turno = turnoOpt.get();
            Inventario inventario = inventarioOpt.get();
            if (inventario.getCantidad() >= cantidad) {
                inventario.setCantidad(inventario.getCantidad() - cantidad);
                turno.setEstado("atendido");
                displayArea.append("Medicamento expendido correctamente.\n");
                displayArea.append("Turno: " + turno.getNumeroTurno() + " atendido.\n");
                displayArea.append("Cantidad Restante: " + inventario.getCantidad() + "\n");
            } else {
                displayArea.append("Cantidad insuficiente en inventario.\n");
            }
        } else {
            displayArea.append("No se encontró la orden para la cédula proporcionada.");
        }
    }
}
