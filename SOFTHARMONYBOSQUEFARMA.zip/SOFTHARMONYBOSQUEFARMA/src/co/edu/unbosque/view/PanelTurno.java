package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import co.edu.unbosque.model.Turno;
import co.edu.unbosque.model.persistence.TurnoDAO;
import java.util.List;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class PanelTurno extends JPanel {

    private static final long serialVersionUID = 1L;

    private JLabel lblDocumentoPaciente;
    private JTextField txtDocumentoPaciente;
    private JButton btnAsignarTurno;
    private JButton btnVerTurnos;
    private JButton btnVolver;
    private JButton btnGenerarReporte;
    private JButton btnResetear;
    private JTextArea txtAreaTurnos;
    private TurnoDAO turnoDAO;
    private Image fondo;

    public static final String ASIGNAR_TURNO = "AsignarTurno";
    public static final String VER_TURNOS = "VerTurnos";
    public static final String VOLVER = "Volver";
    public static final String GENERAR_REPORTE = "GenerarReporte";
    public static final String RESETEAR = "Resetear";

    public PanelTurno(ActionListener listener) {
        setLayout(new GridBagLayout());
        setBackground(new Color(245, 245, 245));

        // Cargar la imagen de fondo
        fondo = new ImageIcon(getClass().getResource("/imagenes/fondoTurnos.png")).getImage();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        turnoDAO = new TurnoDAO();

        
        JLabel lblTitulo = new JLabel("Gestión de Turnos");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(new Color(0, 102, 204));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(lblTitulo, gbc);

       
        lblDocumentoPaciente = new JLabel("Documento del Paciente:");
        lblDocumentoPaciente.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;
        add(lblDocumentoPaciente, gbc);

        txtDocumentoPaciente = new JTextField();
        txtDocumentoPaciente.setFont(new Font("Arial", Font.PLAIN, 14));
        txtDocumentoPaciente.setPreferredSize(new Dimension(200, 25));
        txtDocumentoPaciente.setBorder(BorderFactory.createLineBorder(new Color(0, 102, 204)));
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(txtDocumentoPaciente, gbc);

        
        btnAsignarTurno = new JButton("Asignar Turno");
        btnAsignarTurno.setFont(new Font("Arial", Font.BOLD, 14));
        btnAsignarTurno.setBackground(new Color(0, 102, 204));
        btnAsignarTurno.setForeground(Color.WHITE);
        btnAsignarTurno.setPreferredSize(new Dimension(150, 40));
        btnAsignarTurno.setActionCommand(ASIGNAR_TURNO);
        btnAsignarTurno.addActionListener(listener);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        add(btnAsignarTurno, gbc);
        btnVerTurnos = new JButton("Ver Turnos");
        btnVerTurnos.setFont(new Font("Arial", Font.BOLD, 14));
        btnVerTurnos.setBackground(new Color(0, 153, 51));
        btnVerTurnos.setForeground(Color.WHITE);
        btnVerTurnos.setPreferredSize(new Dimension(150, 40));
        btnVerTurnos.setActionCommand(VER_TURNOS);
        btnVerTurnos.addActionListener(listener);
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(btnVerTurnos, gbc);

        btnVolver = new JButton("Volver");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 14));
        btnVolver.setBackground(new Color(255, 102, 102));
        btnVolver.setForeground(Color.WHITE);
        btnVolver.setPreferredSize(new Dimension(150, 40));
        btnVolver.setActionCommand(VOLVER);
        btnVolver.addActionListener(listener);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        add(btnVolver, gbc);

        btnGenerarReporte = new JButton("Generar Reporte");
        btnGenerarReporte.setFont(new Font("Arial", Font.BOLD, 14));
        btnGenerarReporte.setBackground(new Color(255, 204, 0));
        btnGenerarReporte.setForeground(Color.WHITE);
        btnGenerarReporte.setPreferredSize(new Dimension(150, 40));
        btnGenerarReporte.setActionCommand(GENERAR_REPORTE);
        btnGenerarReporte.addActionListener(listener);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        add(btnGenerarReporte, gbc);

        
        btnResetear = new JButton("Resetear Turnos");
        btnResetear.setFont(new Font("Arial", Font.BOLD, 14));
        btnResetear.setBackground(new Color(255, 51, 51)); // Color rojo
        btnResetear.setForeground(Color.WHITE);
        btnResetear.setPreferredSize(new Dimension(150, 40));
        btnResetear.setActionCommand(RESETEAR);
        btnResetear.addActionListener(listener);
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        add(btnResetear, gbc);

        
        txtAreaTurnos = new JTextArea();
        txtAreaTurnos.setFont(new Font("Arial", Font.PLAIN, 14));
        txtAreaTurnos.setPreferredSize(new Dimension(400, 200));
        txtAreaTurnos.setEditable(false);
        txtAreaTurnos.setBorder(BorderFactory.createLineBorder(new Color(0, 102, 204)));
        txtAreaTurnos.setBackground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        add(txtAreaTurnos, gbc);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (fondo != null) {
            g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
        }
    }

    public String getDocumentoPaciente() {
        return txtDocumentoPaciente.getText();
    }

    public void mostrarTurnos(List<Turno> turnos) {
        StringBuilder sb = new StringBuilder();
        for (Turno turno : turnos) {
            sb.append("Turno: ").append(turno.getNumeroTurno()).append(", Documento: ")
                    .append(turno.getDocumentoPaciente()).append(", Estado: ").append(turno.getEstado()).append("\n");
        }
        txtAreaTurnos.setText(sb.toString());
    }

    public List<Turno> obtenerTurnos() {
        return turnoDAO.obtenerTodosLosTurnos();
    }

    public void generarReporte(List<Turno> turnos) {
        StringBuilder sb = new StringBuilder();
        sb.append("Reporte de Turnos\n");
        sb.append("=================\n");

        for (Turno turno : turnos) {
            sb.append("Turno: ").append(turno.getNumeroTurno()).append(", Documento: ")
                    .append(turno.getDocumentoPaciente()).append(", Estado: ").append(turno.getEstado()).append("\n");
        }

        System.out.println("Generando reporte con " + turnos.size() + " turnos.");

        
        String rutaArchivo = "reporte_turnos.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo))) {
            writer.write(sb.toString());
            JOptionPane.showMessageDialog(this, "Reporte generado exitosamente: " + rutaArchivo);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al generar el reporte: " + ex.getMessage());
        }
    }

    
    public void resetearTurnos() {
        turnoDAO.eliminarTodos(); 
        try {
            turnoDAO.guardar(); 
            txtAreaTurnos.setText("Todos los turnos han sido eliminados.\n");
            mostrarTurnos(turnoDAO.obtenerTodosLosTurnos()); 
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar los turnos: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace(); 
        }
    }
}