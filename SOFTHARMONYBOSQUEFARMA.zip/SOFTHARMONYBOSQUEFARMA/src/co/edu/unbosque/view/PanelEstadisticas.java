package co.edu.unbosque.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelEstadisticas extends JPanel {
    private static final long serialVersionUID = 1L;
    private JTextArea textAreaEstadisticas;
    private JButton botonGenerarEstadisticas;
    private JButton botonVolver;
    private Image fondo;

    public PanelEstadisticas(ActionListener listener) {
    
        setLayout(new BorderLayout());
        setBackground(new Color(240, 240, 240));  
        setBorder(BorderFactory.createCompoundBorder(
                new EmptyBorder(20, 20, 20, 20),
                BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(100, 100, 100)),
                        "Estadísticas",
                        TitledBorder.CENTER,
                        TitledBorder.TOP,
                        new Font("Arial", Font.BOLD, 20),
                        new Color(50, 50, 50))
        ));

        
        fondo = new ImageIcon(getClass().getResource("/imagenes/fondoEstadistica.png")).getImage();
        textAreaEstadisticas = new JTextArea();
        textAreaEstadisticas.setEditable(false);
        textAreaEstadisticas.setFont(new Font("Monospaced", Font.PLAIN, 14)); 
        textAreaEstadisticas.setLineWrap(true);
        textAreaEstadisticas.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(textAreaEstadisticas);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); 

        
        botonGenerarEstadisticas = new JButton("Generar Estadísticas");
        botonGenerarEstadisticas.setActionCommand(PanelControl.ESTADISTICAS);
        botonGenerarEstadisticas.addActionListener(listener);
        botonGenerarEstadisticas.setFont(new Font("Arial", Font.BOLD, 14));
        botonGenerarEstadisticas.setBackground(new Color(70, 130, 180));
        botonGenerarEstadisticas.setForeground(Color.WHITE);
        botonGenerarEstadisticas.setFocusPainted(false);
        botonGenerarEstadisticas.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botonGenerarEstadisticas.setBorder(BorderFactory.createLineBorder(new Color(50, 50, 50), 2));
        botonGenerarEstadisticas.setPreferredSize(new Dimension(200, 40));

       
        botonGenerarEstadisticas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonGenerarEstadisticas.setBackground(new Color(100, 150, 200));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonGenerarEstadisticas.setBackground(new Color(70, 130, 180));
            }
        });

    
        botonVolver = new JButton("Volver");
        botonVolver.setActionCommand("Volver");
        botonVolver.addActionListener(listener);
        botonVolver.setFont(new Font("Arial", Font.BOLD, 14));
        botonVolver.setBackground(new Color(220, 70, 70));
        botonVolver.setForeground(Color.WHITE);
        botonVolver.setFocusPainted(false);
        botonVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botonVolver.setBorder(BorderFactory.createLineBorder(new Color(50, 50, 50), 2));
        botonVolver.setPreferredSize(new Dimension(200, 40));


        botonVolver.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonVolver.setBackground(new Color(240, 100, 100));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonVolver.setBackground(new Color(220, 70, 70));
            }
        });


        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10)); 
        panelBotones.setOpaque(false); 
        panelBotones.add(botonGenerarEstadisticas);
        panelBotones.add(botonVolver);

 
        add(scrollPane, BorderLayout.CENTER); 
        add(panelBotones, BorderLayout.SOUTH); 
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (fondo != null) {
            g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this); 
        }
    }
    public void mostrarEstadisticas(String estadisticas) {
        textAreaEstadisticas.setText(estadisticas);
    }

    public void limpiarEstadisticas() {
        textAreaEstadisticas.setText("");
    }
}