package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelRegistro extends JPanel {
    private static final long serialVersionUID = 1L;
    private JTextField usuario;
    private JTextField correo;
    private JPasswordField contraseña;
    private JTextField cedula;
    private JButton btnRegistrar;
    private JButton btnRegresar;

    public static final String REGRESAR = "Regresar";
    public static final String REGISTRAR_USUARIO = "RegistrarUsuario";

    private Image backgroundImage;

    public PanelRegistro(ActionListener listener) {
        setLayout(null); 
        setBackground(new Color(245, 245, 245));

       
        backgroundImage = new ImageIcon(getClass().getResource("/imagenes/fondoPanelRegistro.png")).getImage();

        
        JLabel lblTitulo = new JLabel("Registro de Usuario");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(new Color(0, 102, 204));
        lblTitulo.setBounds(100, 20, 200, 30);
        add(lblTitulo);

     
        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(new Font("Arial", Font.PLAIN, 14));
        lblUsuario.setBounds(50, 70, 100, 25);
        add(lblUsuario);

        usuario = new JTextField();
        usuario.setFont(new Font("Arial", Font.PLAIN, 14));
        usuario.setBounds(150, 70, 200, 25);
        add(usuario);

       
        JLabel lblCorreo = new JLabel("Correo:");
        lblCorreo.setFont(new Font("Arial", Font.PLAIN, 14));
        lblCorreo.setBounds(50, 110, 100, 25);
        add(lblCorreo);

        correo = new JTextField();
        correo.setFont(new Font("Arial", Font.PLAIN, 14));
        correo.setBounds(150, 110, 200, 25);
        add(correo);

        
        JLabel lblContraseña = new JLabel("Contraseña:");
        lblContraseña.setFont(new Font("Arial", Font.PLAIN, 14));
        lblContraseña.setBounds(50, 150, 100, 25);
        add(lblContraseña);

        contraseña = new JPasswordField();
        contraseña.setFont(new Font("Arial", Font.PLAIN, 14));
        contraseña.setBounds(150, 150, 200, 25);
        add(contraseña);


        JLabel lblCedula = new JLabel("Cédula:");
        lblCedula.setFont(new Font("Arial", Font.PLAIN, 14));
        lblCedula.setBounds(50, 190, 100, 25);
        add(lblCedula);

        cedula = new JTextField();
        cedula.setFont(new Font("Arial", Font.PLAIN, 14));
        cedula.setBounds(150, 190, 200, 25);
        add(cedula);

     
        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setFont(new Font("Arial", Font.BOLD, 14));
        btnRegistrar.setBackground(new Color(0, 102, 204));
        btnRegistrar.setForeground(Color.WHITE);
        btnRegistrar.setBounds(100, 230, 150, 40);
        btnRegistrar.setActionCommand(REGISTRAR_USUARIO);
        btnRegistrar.addActionListener(listener);
        add(btnRegistrar);

      
        btnRegresar = new JButton("Regresar");
        btnRegresar.setFont(new Font("Arial", Font.BOLD, 14));
        btnRegresar.setBackground(new Color(255, 0, 0));
        btnRegresar.setForeground(Color.WHITE);
        btnRegresar.setBounds(260, 230, 150, 40);
        btnRegresar.setActionCommand(REGRESAR);
        btnRegresar.addActionListener(listener);
        add(btnRegresar);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }

    public String getUsuario() {
        return usuario.getText();
    }

    public String getCorreo() {
        return correo.getText();
    }

    public String getContraseña() {
        return new String(contraseña.getPassword());
    }

    public String getCedula() {
        return cedula.getText();
    }
}