package co.edu.unbosque.view;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelControl extends JPanel {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    public static final String FUNCIONARIOS = "Funcionarios";
    public static final String INVENTARIO = "Inventario";
    public static final String TURNOS = "Turnos";
    public static final String EXPENDIO = "Expendio";
    public static final String ESTADISTICAS = "Estadisticas";  

    
    private JButton funcionariosButton;
    private JButton inventarioButton;
    private JButton turnosButton;
    private JButton expendioButton;
    private JButton estadisticasButton;  

    
    private static final Font BUTTON_FONT = new Font("SansSerif", Font.BOLD, 14);
    private static final Color BUTTON_BACKGROUND_COLOR = new Color(255, 255, 255);
    private static final Color BUTTON_TEXT_COLOR = new Color(0, 0, 0);
    private static final Color BUTTON_HOVER_COLOR = new Color(230, 230, 230);

    public PanelControl(ActionListener listener) {
        setLayout(new GridLayout(5, 1, 15, 15));  
        setBackground(new Color(245, 245, 245));  
        setBorder(BorderFactory.createCompoundBorder(
                new EmptyBorder(20, 20, 20, 20), 
                BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(100, 100, 100)), 
                                                 "Opciones de Control", 
                                                 TitledBorder.CENTER, 
                                                 TitledBorder.TOP, 
                                                 new Font("SansSerif", Font.BOLD, 18), 
                                                 new Color(80, 80, 80))
        ));

        
        funcionariosButton = createStyledButton("Ver Funcionarios", FUNCIONARIOS, listener);
        inventarioButton = createStyledButton("Ver Inventario", INVENTARIO, listener);
        turnosButton = createStyledButton("Ver Turnos", TURNOS, listener);
        expendioButton = createStyledButton("Expendio de Medicamentos", EXPENDIO, listener);
        estadisticasButton = createStyledButton("Ver Estadísticas", ESTADISTICAS, listener);  

        
        add(funcionariosButton);
        add(inventarioButton);
        add(turnosButton);
        add(expendioButton);
        add(estadisticasButton);  
    }

    
    private JButton createStyledButton(String text, String actionCommand, ActionListener listener) {
        JButton button = new JButton(text);
        button.setActionCommand(actionCommand);
        button.addActionListener(listener);
        button.setFont(BUTTON_FONT);
        button.setBackground(BUTTON_BACKGROUND_COLOR);
        button.setForeground(BUTTON_TEXT_COLOR);
        button.setFocusPainted(false);
        button.setBorder(createButtonBorder());  
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Efecto hover (cambio de color al pasar el mouse)
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(BUTTON_HOVER_COLOR);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(BUTTON_BACKGROUND_COLOR);
            }
        });

        return button;
    }

    
    private Border createButtonBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(150, 150, 150), 2),  // Borde gris
                BorderFactory.createEmptyBorder(15, 20, 15, 20) 
        );
    }
}
