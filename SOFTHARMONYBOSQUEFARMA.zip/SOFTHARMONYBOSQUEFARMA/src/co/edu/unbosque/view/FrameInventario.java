package co.edu.unbosque.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import co.edu.unbosque.controller.Controller;

public class FrameInventario extends JFrame {

	private static final long serialVersionUID = 1L;
	private Controller controller;
	private JTable tableInventario;
	private DefaultTableModel model;
	private JButton btnAgregar, btnEditar, btnEliminar, btnGuardar;

	public FrameInventario(Controller controller) {
		this.controller = controller;
		setTitle("Gestión de Inventario");
		setSize(800, 500);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());

		initComponentes();
	}

	private void initComponentes() {
		
		JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panelBotones.setBackground(new Color(230, 230, 230)); 
		btnAgregar = createButton("Agregar", new Color(0, 123, 255), new Font("Arial", Font.BOLD, 14));
		btnEditar = createButton("Editar", new Color(255, 159, 0), new Font("Arial", Font.BOLD, 14));
		btnEliminar = createButton("Eliminar", new Color(255, 72, 72), new Font("Arial", Font.BOLD, 14));
		btnGuardar = createButton("Guardar", new Color(40, 167, 69), new Font("Arial", Font.BOLD, 14));

		panelBotones.add(btnAgregar);
		panelBotones.add(btnEditar);
		panelBotones.add(btnEliminar);
		panelBotones.add(btnGuardar);

		add(panelBotones, BorderLayout.NORTH);

		
		String[] columnNames = { "ID", "Nombre", "Cantidad" };
		model = new DefaultTableModel(columnNames, 0);
		tableInventario = new JTable(model);
		tableInventario.setFont(new Font("Arial", Font.PLAIN, 14));
		tableInventario.setSelectionBackground(new Color(255, 230, 153)); // Color cuando seleccionas una fila

		
		tableInventario.setRowHeight(30);
		tableInventario.setGridColor(Color.LIGHT_GRAY);
		tableInventario.setShowGrid(true);
		tableInventario.setIntercellSpacing(new Dimension(0, 0));
		tableInventario.getTableHeader().setBackground(new Color(0, 123, 255));
		tableInventario.getTableHeader().setForeground(Color.WHITE);
		tableInventario.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));

		JScrollPane scrollPane = new JScrollPane(tableInventario);
		add(scrollPane, BorderLayout.CENTER);

		cargarDatosInventario();

		
		btnAgregar.addActionListener(e -> agregarItem());
		btnEditar.addActionListener(e -> editarItem());
		btnEliminar.addActionListener(e -> eliminarItem());
		btnGuardar.addActionListener(e -> guardarInventario());
	}

	private JButton createButton(String text, Color color, Font font) {
		JButton button = new JButton(text);
		button.setFont(font);
		button.setBackground(color);
		button.setForeground(Color.WHITE);
		button.setPreferredSize(new Dimension(120, 40));
		button.setFocusPainted(false);
		button.setBorder(BorderFactory.createLineBorder(Color.GRAY));
		return button;
	}

	public void cargarDatosInventario() {
		model.setRowCount(0); 

		Object[][] inventario = controller.obtenerInventario();
		for (Object[] item : inventario) {
			model.addRow(item);
		}
	}

	private void agregarItem() {
		String nombre = JOptionPane.showInputDialog("Nombre del producto:");
		String cantidadStr = JOptionPane.showInputDialog("Cantidad:");

		if (nombre != null && cantidadStr != null) {
			try {
				int cantidad = Integer.parseInt(cantidadStr);

				controller.agregarItemInventario(nombre, cantidad);
				cargarDatosInventario();
			} catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(this,
						"Por favor, ingrese valores numéricos válidos para cantidad y precio.", "Error de entrada",
						JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	private void editarItem() {
		int selectedRow = tableInventario.getSelectedRow();
		if (selectedRow != -1) {
			String id = String.valueOf(model.getValueAt(selectedRow, 0)); // Convertir a String
			String nombre = JOptionPane.showInputDialog("Nuevo nombre:", model.getValueAt(selectedRow, 1));
			String cantidadStr = JOptionPane.showInputDialog("Nueva cantidad:", model.getValueAt(selectedRow, 2));
			String precioStr = JOptionPane.showInputDialog("Nuevo precio:", model.getValueAt(selectedRow, 3));

			if (nombre != null && cantidadStr != null && precioStr != null) {
				try {
					int cantidad = Integer.parseInt(cantidadStr);
					double precio = Double.parseDouble(precioStr);
					controller.editarItemInventario(id, nombre, cantidad, precio);
					cargarDatosInventario();
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(this,
							"Por favor, ingrese valores numéricos válidos para cantidad y precio.", "Error de entrada",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		} else {
			JOptionPane.showMessageDialog(this, "Seleccione un ítem para editar.");
		}
	}

	private void eliminarItem() {
		int selectedRow = tableInventario.getSelectedRow();
		if (selectedRow != -1) {
			String id = String.valueOf(model.getValueAt(selectedRow, 0));
			controller.eliminarItemInventario(id);
			cargarDatosInventario();
		} else {
			JOptionPane.showMessageDialog(this, "Seleccione un ítem para eliminar.");
		}
	}

	private void guardarInventario() {
		try {
			controller.guardarInventario();
			JOptionPane.showMessageDialog(this, "Inventario guardado correctamente.");
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Error al guardar el inventario: " + e.getMessage(), "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}
}
