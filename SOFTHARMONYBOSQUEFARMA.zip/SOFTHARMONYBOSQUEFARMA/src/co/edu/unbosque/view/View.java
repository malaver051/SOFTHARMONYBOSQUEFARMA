package co.edu.unbosque.view;

import java.awt.event.ActionListener;
import co.edu.unbosque.controller.Controller;

public class View {

    private final PanelPrincipal panelPrincipal;
    private final FrameRegistro frameRegistro;
    private final PanelTurno panelTurno;
    private final PanelFuncionario panelFuncionario; 

    public View(ActionListener listener, Controller controller) {
        this.panelPrincipal = new PanelPrincipal(controller);
        this.frameRegistro = new FrameRegistro(listener);
        this.panelTurno = new PanelTurno(listener);
        this.panelFuncionario = new PanelFuncionario(controller); 
    }

    public PanelPrincipal getPanelPrincipal() {
        return panelPrincipal;
    }

    public FrameRegistro getFrameRegistro() {
        return frameRegistro;
    }

    public PanelTurno getPanelTurno() {
        return panelTurno;
    }

    public PanelFuncionario getPanelFuncionario() {
        return panelFuncionario; 
    }
}
