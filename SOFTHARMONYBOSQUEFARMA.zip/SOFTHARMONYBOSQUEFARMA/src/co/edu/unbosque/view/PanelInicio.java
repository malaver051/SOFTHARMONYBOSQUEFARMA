package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import co.edu.unbosque.model.Funcionario;
import co.edu.unbosque.model.persistence.FuncionarioDAO;
import java.util.Optional;

public class PanelInicio extends JPanel implements ActionListener {

	private static final long serialVersionUID = 1L;

	private JLabel cedula;
	private JLabel contraseña;
	private JTextField cedulatxt;
	private JPasswordField contraseñatxt;
	private JButton butIngresar;
	private JButton butRegistrar;
	private JLabel bienvenidaLabel;

	public static final String INGRESAR = "Ingresar";
	public static final String REGISTRO = "Registro";

	private FuncionarioDAO funcionarioDAO;
	private CardLayout cardLayout;
	private Image fondo;

	public PanelInicio(ActionListener listener) {
		setLayout(new CardLayout());
		cardLayout = (CardLayout) getLayout();
		setBackground(new Color(240, 240, 240));
		funcionarioDAO = new FuncionarioDAO();

		fondo = new ImageIcon(getClass().getResource("/imagenes/fondoPanelInicio.png")).getImage();

		JPanel panelLogin = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);

				g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
			}
		};
		panelLogin.setLayout(null);
		panelLogin.setPreferredSize(new Dimension(1280, 720));
		panelLogin.setOpaque(false);

		bienvenidaLabel = new JLabel("");
		bienvenidaLabel.setFont(new Font("Roboto", Font.BOLD, 40));
		bienvenidaLabel.setForeground(new Color(0, 122, 255));
		bienvenidaLabel.setBounds(0, 100, 1280, 50);
		bienvenidaLabel.setHorizontalAlignment(SwingConstants.CENTER);
		bienvenidaLabel.setVerticalAlignment(SwingConstants.CENTER);
		panelLogin.add(bienvenidaLabel);

		cedula = new JLabel("Cédula:");
		cedula.setBounds(470, 260, 300, 20);
		cedula.setForeground(Color.BLACK);
		cedula.setFont(new Font("Arial", Font.BOLD, 14));
		panelLogin.add(cedula);

		cedulatxt = new JTextField();
		cedulatxt.setBounds(530, 250, 300, 50);
		cedulatxt.setFont(new Font("Arial", Font.PLAIN, 16));
		cedulatxt.setBorder(BorderFactory.createLineBorder(new Color(102, 102, 102), 1));
		cedulatxt.setHorizontalAlignment(JTextField.CENTER);
		panelLogin.add(cedulatxt);

		contraseña = new JLabel("Contraseña:");
		contraseña.setBounds(440, 345, 300, 50);
		contraseña.setForeground(Color.BLACK);
		contraseña.setFont(new Font("Arial", Font.BOLD, 14));
		panelLogin.add(contraseña);

		contraseñatxt = new JPasswordField();
		contraseñatxt.setBounds(530, 345, 300, 50);
		contraseñatxt.setFont(new Font("Arial", Font.PLAIN, 16));
		contraseñatxt.setBorder(BorderFactory.createLineBorder(new Color(102, 102, 102), 1));
		contraseñatxt.setHorizontalAlignment(JPasswordField.CENTER);
		panelLogin.add(contraseñatxt);

		butIngresar = new JButton("Ingresar");
		butIngresar.setBounds(515, 420, 150, 60);
		butIngresar.setForeground(Color.WHITE);
		butIngresar.setBackground(new Color(0, 122, 255));
		butIngresar.setFont(new Font("Roboto", Font.BOLD, 16));
		butIngresar.setBorder(BorderFactory.createLineBorder(new Color(0, 102, 204), 2));
		butIngresar.setActionCommand(INGRESAR);
		butIngresar.addActionListener(listener);
		butIngresar.setFocusPainted(false);
		butIngresar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		panelLogin.add(butIngresar);

		butRegistrar = new JButton("Registro");
		butRegistrar.setBounds(695, 420, 150, 60);
		butRegistrar.setForeground(Color.WHITE);
		butRegistrar.setBackground(new Color(0, 122, 255));
		butRegistrar.setFont(new Font("Roboto", Font.BOLD, 16));
		butRegistrar.setBorder(BorderFactory.createLineBorder(new Color(0, 102, 204), 2));
		butRegistrar.setActionCommand(REGISTRO);
		butRegistrar.addActionListener(listener);
		butRegistrar.setFocusPainted(false);
		butRegistrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		panelLogin.add(butRegistrar);

		cedulatxt.setBorder(
				BorderFactory.createCompoundBorder(cedulatxt.getBorder(), BorderFactory.createEmptyBorder(5, 5, 5, 5)));
		contraseñatxt.setBorder(BorderFactory.createCompoundBorder(contraseñatxt.getBorder(),
				BorderFactory.createEmptyBorder(5, 5, 5, 5)));

		add(panelLogin);
	}

	public void setActionListener(ActionListener listener) {
		butIngresar.addActionListener(listener);
		butRegistrar.addActionListener(listener);
	}

	public String getCedulaText() {
		return cedulatxt.getText();
	}

	public String getContraseñaText() {
		return new String(contraseñatxt.getPassword());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		switch (command) {
		case INGRESAR:
			if (validarCredenciales(getCedulaText(), getContraseñaText())) {
				cardLayout.show(this, "Funcionarios");
			} else {
				JOptionPane.showMessageDialog(this, "Credenciales incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
			}
			break;

		default:
			JOptionPane.showMessageDialog(this, "Acción no reconocida", "Error", JOptionPane.ERROR_MESSAGE);
			break;
		}
	}

	private boolean validarCredenciales(String cedula, String contraseña) {
		Optional<Funcionario> funcionario = funcionarioDAO.buscarPorCedula(cedula);
		return funcionario.isPresent() && funcionario.get().getContraseña().equals(contraseña);
	}
}