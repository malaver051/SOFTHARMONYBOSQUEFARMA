package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.event.ActionListener;

public class FrameRegistro extends JFrame {
	private static final long serialVersionUID = 1L;
	private PanelRegistro panelRegistro;

	public FrameRegistro(ActionListener listener) {
		panelRegistro = new PanelRegistro(listener);
		this.setTitle("Registro de Usuario");
		this.setSize(1280, 720); 
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE); 
		this.setResizable(false);
		this.add(panelRegistro);
	}

	public PanelRegistro getPanelRegistro() {
		return panelRegistro;
	}
}
