package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import co.edu.unbosque.model.Funcionario;
import co.edu.unbosque.model.Inventario;
import co.edu.unbosque.model.Turno;
import co.edu.unbosque.model.persistence.FuncionarioDAO;
import co.edu.unbosque.model.persistence.InventarioDAO;
import co.edu.unbosque.model.persistence.TurnoDAO;
import co.edu.unbosque.controller.Controller;

public class PanelPrincipal extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private PanelInicio panelInicio;
    private PanelControl panelControl;
    private PanelFuncionario panelFuncionario;
    private FrameInventario frameInventario;
    private PanelRegistro panelRegistro;
    private PanelTurno panelTurno;
    private PanelExpendio panelExpendio;
    private PanelEstadisticas panelEstadisticas; 
    private CardLayout cardLayout;
    private FuncionarioDAO funcionarioDAO;
    private InventarioDAO inventarioDAO;
    private TurnoDAO turnoDAO;
    private JLabel imagen;
    
    public PanelPrincipal(Controller controller) {
        setTitle("Gestión de Recursos");
        setSize(1280, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        funcionarioDAO = new FuncionarioDAO();
        inventarioDAO = new InventarioDAO();
        turnoDAO = new TurnoDAO();

        cardLayout = new CardLayout();
        setLayout(cardLayout);

        panelInicio = new PanelInicio(this);
        panelControl = new PanelControl(this);
        panelFuncionario = new PanelFuncionario(this);
        frameInventario = new FrameInventario(controller);
        panelRegistro = new PanelRegistro(this);
        panelTurno = new PanelTurno(this);
        panelExpendio = new PanelExpendio(this);
        panelEstadisticas = new PanelEstadisticas(this); 

        add(panelInicio, "Inicio");
        add(panelControl, "Control");
        add(panelFuncionario, "Funcionarios");
        add(panelRegistro, "Registro");
        add(panelTurno, "Turnos");
        add(panelExpendio, "Expendio");
        add(panelEstadisticas, "Estadisticas"); 

        cardLayout.show(getContentPane(), "Inicio");

        imagen = new JLabel();
        imagen.setIcon(new ImageIcon("C:\\Users\\adminpc\\Desktop\\unbosque.edu\\SOTHARMONYBOSQUEFARMA.zip_expanded\\SOFTHARMONYBOSQUEFARMA\\src\\imagenes\\fondoPanelPrincipal.png"));
        imagen.setBounds(50, 5, 90000, 600);
        add(imagen);
        
        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    funcionarioDAO.guardar();
                } catch (IOException ex) {
                    System.err.println("Error al guardar los datos de los funcionarios: " + ex.getMessage());
                }
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        switch (command) {
            case PanelInicio.INGRESAR:
                if (validarCredenciales(panelInicio.getCedulaText(), panelInicio.getContraseñaText())) {
                    cardLayout.show(getContentPane(), "Control");
                } else {
                    JOptionPane.showMessageDialog(this, "Credenciales incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
                }
                break;

            case PanelInicio.REGISTRO:
                cardLayout.show(getContentPane(), "Registro");
                break;

            case PanelControl.FUNCIONARIOS:
                cardLayout.show(getContentPane(), "Funcionarios");
                break;

            case PanelControl.INVENTARIO:
                frameInventario.setVisible(true);
                break;

            case PanelControl.TURNOS:
                cardLayout.show(getContentPane(), "Turnos");
                break;

            case PanelControl.EXPENDIO:
                cardLayout.show(getContentPane(), "Expendio");
                break;

            case PanelControl.ESTADISTICAS: 
                mostrarEstadisticas();
                break;

            case PanelExpendio.BUSCAR:
                buscarOrden();
                break;

            case PanelExpendio.EXPENDER:
                expenderMedicamentos();
                break;

            case PanelFuncionario.LIST:
                List<Funcionario> listaFuncionarios = funcionarioDAO.obtenerLista(); 
                panelFuncionario.mostrarFuncionarios(listaFuncionarios);
                break;

            case PanelFuncionario.VOL:
                cardLayout.show(getContentPane(), "Control");
                break;

            case PanelFuncionario.ELI:
                eliminarFuncionario();
                break;

            case PanelRegistro.REGISTRAR_USUARIO:
                registrarNuevoUsuario();
                break;

            case PanelRegistro.REGRESAR:
                cardLayout.show(getContentPane(), "Inicio");
                break;

            case PanelTurno.ASIGNAR_TURNO:
                asignarTurno();
                break;

            case PanelTurno.VER_TURNOS:
                verTurnos();
                break;

            default:
                JOptionPane.showMessageDialog(this, "Acción no reconocida", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private boolean validarCredenciales(String cedula, String contraseña) {
        Optional<Funcionario> funcionario = funcionarioDAO.buscarPorCedula(cedula);
        return funcionario.isPresent() && funcionario.get().getContraseña().equals(contraseña);
    }

    private void registrarNuevoUsuario() {
        String nombre = panelRegistro.getUsuario();
        String cedula = panelRegistro.getCedula();
        String contraseña = panelRegistro.getContraseña();
        String correo = panelRegistro.getCorreo();

        if (!nombre.isEmpty() && !cedula.isEmpty() && !contraseña.isEmpty() && !correo.isEmpty()) {
            Funcionario nuevoFuncionario = new Funcionario(nombre, cedula, contraseña, correo);
            funcionarioDAO.agregar(nuevoFuncionario);
            JOptionPane.showMessageDialog(this, "Usuario registrado con éxito", "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void mostrarOrden(Optional<Turno> turnoOpt, Optional<Inventario> inventarioOpt) {
        if (turnoOpt.isPresent() && inventarioOpt.isPresent()) {
            Turno turno = turnoOpt.get();
            Inventario inventario = inventarioOpt.get();
            
           
            JOptionPane.showMessageDialog(this,
                "Turno encontrado: " + turno.getNumeroTurno() + "\n" +
                "Medicamento disponible: " + inventario.getNombreMedicamento() + " (Cantidad: " + inventario.getCantidad() + ")",
                "Orden encontrada",
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró una orden con la cédula proporcionada o el inventario está vacío.",
                    "No encontrado", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void asignarTurno() {
        String documentoPaciente = panelTurno.getDocumentoPaciente();
        if (!documentoPaciente.isEmpty()) {
            int numeroTurno = turnoDAO.generarNumeroTurno();
            Turno nuevoTurno = new Turno(numeroTurno, documentoPaciente, "por atender");
            turnoDAO.agregar(nuevoTurno);
            try {
                turnoDAO.guardar();
                JOptionPane.showMessageDialog(this, "Turno asignado: " + numeroTurno, "Éxito",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error al guardar el turno: " + e.getMessage(), "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese el documento del paciente.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void verTurnos() {
        List<Turno> turnos = turnoDAO.obtenerLista();
        panelTurno.mostrarTurnos(turnos);
    }

    public void buscarOrden() {
        String cedula = panelExpendio.getCedula();
        Optional<Turno> turnoOpt = turnoDAO.obtenerLista().stream()
                .filter(t -> t.getDocumentoPaciente().equals(cedula) && t.getEstado().equals("por atender"))
                .findFirst();
        Optional<Inventario> inventarioOpt = inventarioDAO.obtenerLista().stream()
                .filter(i -> i.getCantidad() > 0)
                .findFirst();
        panelExpendio.mostrarOrden(turnoOpt, inventarioOpt);
    }


    public void expenderMedicamentos() {
        String cedula = panelExpendio.getCedula();
        Optional<Turno> turnoOpt = turnoDAO.obtenerLista().stream()
                .filter(t -> t.getDocumentoPaciente().equals(cedula) && t.getEstado().equals("por atender"))
                .findFirst();
        Optional<Inventario> inventarioOpt = inventarioDAO.obtenerLista().stream()
                .filter(i -> i.getCantidad() > 0)
                .findFirst();
        
        if (turnoOpt.isPresent() && inventarioOpt.isPresent()) {
            int cantidad = panelExpendio.getCantidad();
            panelExpendio.expenderMedicamentos(turnoOpt, inventarioOpt, cantidad); 
        } else {
            panelExpendio.mostrarOrden(turnoOpt, inventarioOpt);
        }
    }
 
    private void eliminarFuncionario() {
        String cedulaEliminar = JOptionPane.showInputDialog(this, "Ingrese la cédula del funcionario a eliminar:");
        if (cedulaEliminar != null && !cedulaEliminar.trim().isEmpty()) {
            Optional<Funcionario> funcionarioOpt = funcionarioDAO.buscarPorCedula(cedulaEliminar);
            if (funcionarioOpt.isPresent()) {
                funcionarioDAO.eliminar(cedulaEliminar);
                try {
                    funcionarioDAO.guardar(); 
                    JOptionPane.showMessageDialog(this, "Funcionario eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    
                    
                    List<Funcionario> listaFuncionariosActualizada = funcionarioDAO.obtenerLista();
                    panelFuncionario.mostrarFuncionarios(listaFuncionariosActualizada);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error al guardar los cambios: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Funcionario no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Cédula no válida. Intente nuevamente.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    private void mostrarEstadisticas() {
        
        StringBuilder reporte = new StringBuilder();
        reporte.append("Estadísticas Generales:\n");
        reporte.append("Total de Funcionarios: ").append(funcionarioDAO.obtenerLista().size()).append("\n");
        reporte.append("Total de Turnos: ").append(turnoDAO.obtenerLista().size()).append("\n");
        

        
        panelEstadisticas.mostrarEstadisticas(reporte.toString());
        cardLayout.show(getContentPane(), "Estadisticas"); 
    }

    public CardLayout getCardLayout() {
        return cardLayout;
    }

    public PanelInicio getPanelInicio() {
        return panelInicio;
    }

    public PanelFuncionario getPanelFuncionario() {
        return panelFuncionario;
    }

    public PanelExpendio getPanelExpendio() {
        return panelExpendio;
    }
}