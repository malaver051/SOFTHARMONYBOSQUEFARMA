package co.edu.unbosque.view;

import javax.swing.JFrame;

public class FrameInicio extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private PanelInicio panelInicio;

}
