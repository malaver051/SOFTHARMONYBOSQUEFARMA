package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Optional;

import co.edu.unbosque.model.Funcionario;
import co.edu.unbosque.model.persistence.FuncionarioDAO;

public class PanelFuncionario extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTextArea displayArea;
    private JButton listButton;
    private JButton volButton;
    private JButton eliButton;
    private JTextField searchField;
    private JButton searchButton;
    private FuncionarioDAO funcionarioDAO;
    private Image fondo;

    public static final String LIST = "Listar";
    public static final String VOL = "Volver";
    public static final String ELI = "Eliminar";
    public static final String SEARCH = "Buscar";

    public PanelFuncionario(ActionListener listener) {
        funcionarioDAO = new FuncionarioDAO();
        setLayout(new BorderLayout(15, 15));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        fondo = new ImageIcon(getClass().getResource("/imagenes/fondoPanelFuncionarios.png")).getImage();

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

        listButton = createButton("Listar Funcionarios", LIST, listener);
        volButton = createButton("Volver", VOL, listener);
        eliButton = createButton("Eliminar Funcionario", ELI, listener);
        searchField = new JTextField(15);
        searchButton = createButton("Buscar", SEARCH, listener);
        searchButton.setFont(new Font("SansSerif", Font.BOLD, 12));
        searchButton.setActionCommand("SEARCH");
    



       
        buttonPanel.add(listButton);
        buttonPanel.add(searchField);
        buttonPanel.add(searchButton);
        buttonPanel.add(eliButton);
        buttonPanel.add(volButton);

        
        displayArea = new JTextArea(15, 40);
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        displayArea.setLineWrap(true);
        displayArea.setWrapStyleWord(true);

       
        add(buttonPanel, BorderLayout.NORTH);
        add(new JScrollPane(displayArea), BorderLayout.CENTER);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (fondo != null) {
            g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
        }
    }

    private JButton createButton(String text, String actionCommand, ActionListener listener) {
        JButton button = new JButton(text);
        button.setActionCommand(actionCommand);
        button.addActionListener(listener);
        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        return button;
    }

    public void mostrarFuncionarios(List<Funcionario> funcionarios) {
        displayArea.setText("Lista de Funcionarios:\n");
        for (Funcionario f : funcionarios) {
            displayArea.append("Nombre: " + f.getNombre() + ", Correo: " + f.getCorreo() + "\n");
        }
    }

    public void eliminarFuncionario() {
        String cedula = JOptionPane.showInputDialog(this, "Ingrese la cédula del funcionario a eliminar:");

        if (cedula != null && !cedula.trim().isEmpty()) {
            int confirm = JOptionPane.showConfirmDialog(this, 
                "¿Estás seguro de eliminar al funcionario con cédula " + cedula + "?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
                
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    funcionarioDAO.eliminar(cedula); 

                    
                    Optional<Funcionario> funcionario = funcionarioDAO.buscarPorCedula(cedula);
                    if (funcionario.isPresent()) {
                        
                        JOptionPane.showMessageDialog(this, "No se pudo eliminar el funcionario.", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        
                        displayArea.setText("Funcionario con cédula " + cedula + " eliminado.\n");
                        mostrarFuncionarios(funcionarioDAO.obtenerLista()); 
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Error al eliminar el funcionario: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Cédula no válida. Intente nuevamente.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void buscarFuncionario() {
        String busqueda = searchField.getText().trim();
        System.out.println("Buscando funcionario por nombre: " + busqueda); 
        if (!busqueda.isEmpty()) {
            List<Funcionario> funcionariosEncontrados = funcionarioDAO.buscarPorNombre(busqueda);
            if (!funcionariosEncontrados.isEmpty()) {
                mostrarFuncionarios(funcionariosEncontrados);
            } else {
                JOptionPane.showMessageDialog(this, "No se encontraron funcionarios con ese nombre.", "Resultado de búsqueda", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {	
            JOptionPane.showMessageDialog(this, "Por favor ingrese un nombre para buscar.", "Error de búsqueda", JOptionPane.ERROR_MESSAGE);
        }
    }

    }
