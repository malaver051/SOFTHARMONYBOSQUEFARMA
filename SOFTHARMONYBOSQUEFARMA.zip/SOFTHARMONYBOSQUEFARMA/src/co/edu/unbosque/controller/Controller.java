package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import co.edu.unbosque.model.Estadisticas;
import co.edu.unbosque.model.Facade;
import co.edu.unbosque.model.Funcionario;
import co.edu.unbosque.model.Inventario;
import co.edu.unbosque.model.Turno;
import co.edu.unbosque.model.persistence.FuncionarioDAO;
import co.edu.unbosque.model.persistence.InventarioDAO;
import co.edu.unbosque.model.persistence.TurnoDAO;
import co.edu.unbosque.model.persistence.TurnoDTO;
import co.edu.unbosque.model.persistence.binariosFile;
import co.edu.unbosque.view.View;
import co.edu.unbosque.view.FrameInventario;
import co.edu.unbosque.view.FrameRegistro;
import co.edu.unbosque.view.PanelInicio;
import co.edu.unbosque.view.PanelPrincipal;
import co.edu.unbosque.view.PanelRegistro;
import co.edu.unbosque.view.PanelControl;
import co.edu.unbosque.view.PanelFuncionario;
import co.edu.unbosque.view.PanelExpendio;
import co.edu.unbosque.view.PanelTurno;
import co.edu.unbosque.view.PanelEstadisticas; // Importar PanelEstadisticas

public class Controller implements ActionListener {
	private Facade facade;
	private View view;
	private FuncionarioDAO funcionarioDAO;
	private InventarioDAO inventarioDAO;
	private TurnoDAO turnoDAO;
	private FrameInventario frameInventario;
	private FrameRegistro frameRegistro;
	private binariosFile binariosFile;
	private PanelTurno panelTurno;
	private PanelEstadisticas panelEstadisticas;

	public Controller() {
		binariosFile = new binariosFile();
		funcionarioDAO = new FuncionarioDAO();
		inventarioDAO = new InventarioDAO();
		turnoDAO = new TurnoDAO();
		new PanelFuncionario(this);

		facade = new Facade(funcionarioDAO, inventarioDAO, binariosFile);

		view = new View(this, this);
		frameInventario = new FrameInventario(this);
		frameRegistro = new FrameRegistro(this);
		view.getPanelPrincipal().getPanelInicio().setActionListener(this);

		panelEstadisticas = new PanelEstadisticas(this);

		SwingUtilities.invokeLater(() -> {
			PanelPrincipal ventana = new PanelPrincipal(this);
			ventana.setVisible(true);
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		System.out.println("Evento recibido: " + command);
		try {
			switch (command) {
			case PanelInicio.INGRESAR:
				handleIngresar();
				break;
			case PanelControl.ESTADISTICAS:
				mostrarPanelEstadisticas();
				break;
			case PanelInicio.REGISTRO:
				handleRegistro();
				break;
			case PanelTurno.RESETEAR:
				handleResetearTurnos();
				break;
			case PanelRegistro.REGRESAR:
				handleRegresar();
				break;
			case PanelRegistro.REGISTRAR_USUARIO:
				handleRegistrarUsuario();
				break;
			case PanelControl.FUNCIONARIOS:
				view.getPanelPrincipal().getCardLayout().show(view.getPanelPrincipal().getContentPane(),
						"Funcionarios");
				break;
			case PanelControl.INVENTARIO:
				frameInventario.setVisible(true);
				break;
			case PanelControl.TURNOS:
				view.getPanelPrincipal().getCardLayout().show(view.getPanelPrincipal().getContentPane(), "Turnos");
				break;
			case PanelControl.EXPENDIO:
				view.getPanelPrincipal().getCardLayout().show(view.getPanelPrincipal().getContentPane(), "Expendio");
				break;

			case PanelExpendio.EXPENDER:
				view.getPanelPrincipal().expenderMedicamentos();
				break;
			case "Volver":
				handleVolverDesdeEstadisticas();
				break;
			case PanelFuncionario.LIST:
				handleListarFuncionarios();
				break;
			case PanelFuncionario.ELI:
				handleEliminarFuncionario();
				break;
			case "GenerarReporte":
				List<Turno> turnos = turnoDAO.obtenerTodosLosTurnos();
				if (turnos != null && !turnos.isEmpty()) {
					generarReporte(turnos);
				} else {
					JOptionPane.showMessageDialog(null, "No hay turnos para generar el reporte.");
				}
				break;
			
			case PanelFuncionario.SEARCH:
				view.getPanelFuncionario().buscarFuncionario();
				break;
			}
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Error inesperado: " + ex.getMessage());
			ex.printStackTrace();
		}
	}

	private void mostrarPanelEstadisticas() {
		// Obtener lista de turnos e inventarios
		List<Turno> turnos = turnoDAO.obtenerLista();
		List<Inventario> inventarios = inventarioDAO.obtenerLista();

		
		Estadisticas estadisticas = new Estadisticas(turnos, inventarios);

		// Obtener las estadísticas como un String
		String reporteEstadisticas = estadisticas.toString();

		
		panelEstadisticas.mostrarEstadisticas(reporteEstadisticas);

		
		view.getPanelPrincipal().getCardLayout().show(view.getPanelPrincipal().getContentPane(), "Estadisticas");
	}

	private void cambiarAPanelControl() {
		view.getPanelPrincipal().getCardLayout().show(view.getPanelPrincipal().getContentPane(), "PanelControl");
	}

	private void handleVolverDesdeEstadisticas() {
		cambiarAPanelControl(); 
	}

	private void handleIngresar() {
		String cedula = view.getPanelPrincipal().getPanelInicio().getCedulaText();
		String contraseña = view.getPanelPrincipal().getPanelInicio().getContraseñaText();

		if (cedula.isEmpty() && contraseña.isEmpty()) {
			JOptionPane.showMessageDialog(null, "Por favor, ingrese la cédula y la contraseña.");
		} else {
			Optional<Funcionario> usuarioValido = funcionarioDAO.obtenerLista().stream()
					.filter(u -> u.getCedula().equals(cedula) && u.getContraseña().equals(contraseña)).findFirst();

			usuarioValido.ifPresentOrElse(u -> {
				JOptionPane.showMessageDialog(null, "Ingreso realizado correctamente.");
				view.getPanelPrincipal().getCardLayout().show(view.getPanelPrincipal().getContentPane(), "Control");
			}, () -> JOptionPane.showMessageDialog(null, "Cédula o contraseña incorrectas."));
		}
	}

	private void handleRegistro() {
		frameRegistro.setVisible(true);
	}

	private void handleRegresar() {
		frameRegistro.setVisible(false);
	}

	private void handleRegistrarUsuario() throws IOException {
		if (camposValidos()) {
			Funcionario nuevoUsuario = crearFuncionario();
			facade.agregarFuncionario(nuevoUsuario);
			facade.guardarFuncionarios();
			JOptionPane.showMessageDialog(null, "Registro realizado correctamente.");
			handleRegresar();
		} else {
			JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
		}
	}

	private boolean camposValidos() {
		String usuario = frameRegistro.getPanelRegistro().getUsuario();
		String correo = frameRegistro.getPanelRegistro().getCorreo();
		String contraseña = frameRegistro.getPanelRegistro().getContraseña();
		String cedulaStr = frameRegistro.getPanelRegistro().getCedula();

		boolean emailValido = correo.matches("^[\\w-\\.]+@[\\w-]+\\.[a-z]{2,}$");
		boolean longitudContraseña = contraseña.length() >= 6;

		return !usuario.isEmpty() && !correo.isEmpty() && emailValido && longitudContraseña && !cedulaStr.isEmpty();
	}

	private Funcionario crearFuncionario() {
		String usuario = frameRegistro.getPanelRegistro().getUsuario();
		String correo = frameRegistro.getPanelRegistro().getCorreo();
		String contraseña = frameRegistro.getPanelRegistro().getContraseña();
		String cedulaStr = frameRegistro.getPanelRegistro().getCedula();
		return new Funcionario(usuario, cedulaStr, contraseña, correo);
	}

	public Object[][] obtenerInventario() {
		return inventarioDAO.obtenerLista().stream()
				.map(i -> new Object[] { i.getId(), i.getNombreMedicamento(), i.getCantidad(), })
				.toArray(Object[][]::new);
	}

	public void guardarInventario() throws IOException {
		inventarioDAO.guardar();
	}

	public void agregarItemInventario(String nombre, int cantidad) {
		int newId = inventarioDAO.generarId();
		Inventario item = new Inventario(newId, nombre, cantidad);
		inventarioDAO.agregar(item);
		try {
			inventarioDAO.guardar();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Error al guardar el inventario: " + e.getMessage());
		}
	}

	public void editarItemInventario(String idStr, String nombre, int cantidad, double precio) {
		try {
			int id = Integer.parseInt(idStr);
			Inventario item = new Inventario(id, nombre, cantidad);
			inventarioDAO.actualizar(item, id);
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "ID inválido: " + idStr);
		}
	}

	public void expenderMedicamento(String codigoMedicamento, int cantidad) {
		// Obtener el medicamento directamente desde el InventarioDAO
		Optional<Inventario> medicamentoOpt = inventarioDAO.obtenerLista().stream()
				.filter(m -> m.getNombreMedicamento().equals(codigoMedicamento)).findFirst();

		medicamentoOpt.ifPresentOrElse(medicamento -> {
			if (medicamento.getCantidad() >= cantidad) {
				medicamento.setCantidad(medicamento.getCantidad() - cantidad);
				try {
					inventarioDAO.guardar(); 
					JOptionPane.showMessageDialog(null, "Medicamento expendido correctamente.");
				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Error al expender medicamento: " + e.getMessage());
				}
			} else {
				JOptionPane.showMessageDialog(null, "Cantidad insuficiente en inventario.");
			}
		}, () -> JOptionPane.showMessageDialog(null, "Medicamento no encontrado en inventario."));
	}

	private void generarReporte(List<Turno> turnos) {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("Reporte de Turnos\n");
			sb.append("=================\n");

			for (Turno turno : turnos) {
				sb.append("Turno: ").append(turno.getNumeroTurno()).append(", Documento: ")
						.append(turno.getDocumentoPaciente()).append(", Estado: ").append(turno.getEstado())
						.append("\n");
			}

			// Guardar el reporte en un archivo de texto
			try (BufferedWriter writer = new BufferedWriter(new FileWriter("reporte_turnos.txt"))) {
				writer.write(sb.toString());
				JOptionPane.showMessageDialog(null, "Reporte generado exitosamente: reporte_turnos.txt");
			}
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Error al generar el reporte: " + e.getMessage());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Error inesperado: " + e.getMessage());
		}
	}

	public void asignarTurno(String documentoPaciente) {
		ArrayList<TurnoDTO> listaTurnosDTO;
		try {
			listaTurnosDTO = new ArrayList<>(binariosFile.getListaTurnos());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Error al obtener la lista de turnos: " + e.getMessage());
			return;
		}

		List<Turno> listaTurnos = binariosFile.convertirListaTurnos(listaTurnosDTO);
		int nuevoNumeroTurno = listaTurnos.size() + 1;
		Turno nuevoTurno = new Turno(nuevoNumeroTurno, documentoPaciente, "por atender");
		listaTurnos.add(nuevoTurno);

		try {
			ArrayList<TurnoDTO> nuevaListaTurnosDTO = listaTurnos.stream()
					.map(t -> new TurnoDTO(t.getNumeroTurno(), t.getDocumentoPaciente(), t.getEstado()))
					.collect(Collectors.toCollection(ArrayList::new));
			binariosFile.setListaTurnos(nuevaListaTurnosDTO);
			binariosFile.escribirArchivoTurnos();
			JOptionPane.showMessageDialog(null, "Turno asignado correctamente.");
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Error al asignar turno: " + e.getMessage());
		}
	}

	private void handleResetearTurnos() {
		int confirmacion = JOptionPane.showConfirmDialog(panelTurno,
				"¿Estás seguro de que deseas resetear todos los turnos?", "Confirmación", JOptionPane.YES_NO_OPTION);
		if (confirmacion == JOptionPane.YES_OPTION) {
			try {
				turnoDAO.eliminarTodos(); 
				turnoDAO.guardar(); 
				panelTurno.mostrarTurnos(turnoDAO.obtenerTodosLosTurnos()); 
				JOptionPane.showMessageDialog(panelTurno, "Todos los turnos han sido reseteados correctamente.");
			} catch (IOException ex) {
				JOptionPane.showMessageDialog(panelTurno, "Error al resetear los turnos: " + ex.getMessage());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void handleListarFuncionarios() {
		List<Funcionario> listaFuncionarios = funcionarioDAO.obtenerLista();
		view.getPanelPrincipal().getPanelFuncionario().mostrarFuncionarios(new ArrayList<>(listaFuncionarios));
	}

	private void handleEliminarFuncionario() {
		String cedula = JOptionPane.showInputDialog("Ingrese la cédula del funcionario a eliminar:");
		if (cedula != null && !cedula.trim().isEmpty()) {
			try {
				facade.eliminarFuncionario(cedula);
				facade.guardarFuncionarios(); 
				JOptionPane.showMessageDialog(null, "Funcionario eliminado correctamente.");
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Error al guardar los cambios: " + e.getMessage());
			} catch (IllegalArgumentException e) {
				JOptionPane.showMessageDialog(null, e.getMessage());
			}
		} else {
			JOptionPane.showMessageDialog(null, "Cédula no válida.");
		}
	}

	public void generarEstadisticas() {
		List<Turno> turnos = turnoDAO.obtenerLista(); 
		List<Inventario> inventarios = inventarioDAO.obtenerLista(); 

		
		Estadisticas estadisticas = new Estadisticas(turnos, inventarios);

		
		String reporteEstadisticas = estadisticas.toString();

		
		JOptionPane.showMessageDialog(null, reporteEstadisticas);
	}

	public void eliminarItemInventario(String idStr) {
		try {
			int id = Integer.parseInt(idStr);
			inventarioDAO.eliminar(id);
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "ID inválido: " + idStr);
		}
	}
}
