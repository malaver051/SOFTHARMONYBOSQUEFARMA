package co.edu.unbosque.model;

import java.util.List;
import java.util.stream.Collectors;

public class Estadisticas {
    private List<Turno> turnos;
    private List<Inventario> inventario;

    public Estadisticas(List<Turno> turnos, List<Inventario> inventario) {
        this.turnos = turnos;
        this.inventario = inventario;
    }

   
    public String obtenerTopCincoTurnos() {
        return turnos.stream()
                .sorted((t1, t2) -> Integer.compare(t2.getNumeroTurno(), t1.getNumeroTurno())) // Ordenar por número de turno (descendente)
                .limit(5)
                .map(turno -> "Turno #" + turno.getNumeroTurno() + " - Paciente: " + turno.getDocumentoPaciente() + " - Estado: " + turno.getEstado())
                .collect(Collectors.joining("\n"));
    }

    
    public String obtenerTopCincoMedicamentos() {
        return inventario.stream()
                .sorted((i1, i2) -> Integer.compare(i2.getCantidad(), i1.getCantidad())) // Ordenar por cantidad (descendente)
                .limit(5)
                .map(inventario -> "Medicamento: " + inventario.getNombreMedicamento() + " - Cantidad: " + inventario.getCantidad())
                .collect(Collectors.joining("\n"));
    }

    // Getter y Setter
    public List<Turno> getTurnos() {
        return turnos;
    }

    public void setTurnos(List<Turno> turnos) {
        this.turnos = turnos;
    }

    public List<Inventario> getInventario() {
        return inventario;
    }

    public void setInventario(List<Inventario> inventario) {
        this.inventario = inventario;
    }

    @Override
    public String toString() {
        return "Estadísticas [Top 5 Turnos: " + obtenerTopCincoTurnos() + "\nTop 5 Medicamentos: " + obtenerTopCincoMedicamentos() + "]";
    }
}
