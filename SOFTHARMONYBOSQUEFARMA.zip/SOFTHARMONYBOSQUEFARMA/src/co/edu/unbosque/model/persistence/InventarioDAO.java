package co.edu.unbosque.model.persistence;

import java.io.*;
import java.util.ArrayList;
import java.util.Optional;
import co.edu.unbosque.model.Inventario;

public class InventarioDAO implements CRUD<Inventario, Integer> {

    private ArrayList<Inventario> inventario;
    private binariosFile bf;
    private final String FILE_NAME = "inventario.dat"; 

    public InventarioDAO() {
        inventario = new ArrayList<>();
        bf = new binariosFile();
        try {
            cargarInventario();  
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar el inventario: " + e.getMessage());
        }
    }

    @Override
    public void guardar() throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(inventario); 
            System.out.println("Inventario guardado correctamente.");
        } catch (IOException e) {
            throw new IOException("Error al guardar el inventario: " + e.getMessage(), e);
        }
    }

    @Override
    public void actualizar(Inventario dato, Integer id) {
        eliminar(id);
        agregar(dato);
    }

    @Override
    public void eliminar(Integer id) {
       
        Optional<Inventario> inventarioEncontrado = inventario.stream()
                .filter(e -> e.getId() == id) 
                .findFirst();
        
        inventarioEncontrado.ifPresent(inventario::remove);
        
        try {
            guardar(); 
            System.out.println("Medicamento eliminado: " + id);
        } catch (IOException e) {
            System.err.println("Error al guardar los cambios después de eliminar el medicamento: " + e.getMessage());
        }
    }

    @Override
    public void agregar(Inventario dato) {
        dato.setId(generarId());
        inventario.add(dato);
        try {
            guardar(); 
        } catch (IOException e) {
            System.err.println("Error al guardar los cambios después de agregar el medicamento: " + e.getMessage());
        }
    }

    @Override
    public ArrayList<Inventario> obtenerLista() {
        return inventario;
    }

    public int generarId() {
        return inventario.stream().mapToInt(Inventario::getId).max().orElse(0) + 1;
    }

    @SuppressWarnings("unchecked")
    public void cargarInventario() throws IOException, ClassNotFoundException {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            System.out.println("Archivo de inventario no encontrado, se creará uno nuevo.");
            return;
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            inventario = (ArrayList<Inventario>) ois.readObject(); 
            System.out.println("Inventario cargado correctamente.");
        } catch (IOException | ClassNotFoundException e) {
            throw new IOException("Error al cargar el inventario: " + e.getMessage(), e);
        }
    }

    
    public Inventario obtenerPorId(int id) {
        return inventario.stream()
                         .filter(inventario -> inventario.getId() == id)
                         .findFirst()
                         .orElse(null);  
    }
}
