package co.edu.unbosque.model.persistence;

import java.io.IOException;
import java.util.List;

public interface CRUD<E, T> {
    void guardar() throws IOException;

    void actualizar(E dato, T info);

    void eliminar(T info);

    void agregar(E dato);

    List<E> obtenerLista(); 
}