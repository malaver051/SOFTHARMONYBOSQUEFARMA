package co.edu.unbosque.model.persistence;

import co.edu.unbosque.model.Turno;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TurnoDAO implements CRUD<Turno, Integer> {

	private List<Turno> turnos; 
	private binariosFile binariosFile;

	public TurnoDAO() {
		turnos = new ArrayList<>();
		binariosFile = new binariosFile(); 
		try {
			cargarTurnos(); 
		} catch (IOException | ClassNotFoundException e) {
			System.err.println("Error al cargar los turnos: " + e.getMessage());
		}
	}

	@Override
	public void guardar() throws IOException {
		binariosFile.setListaTurnos(convertirAListaDTO(turnos)); 
		binariosFile.escribirArchivoTurnos(); 
		System.out.println("Turnos guardados.");
	}

	@Override
	public void actualizar(Turno dato, Integer id) {
		eliminar(id); 
		agregar(dato); 
	}

	
	public List<Turno> obtenerTodosLosTurnos() {
		return new ArrayList<>(turnos); 
	}

	
	public void agregarTurno(Turno turno) {
		turnos.add(turno);
	}

	@Override
	public void eliminar(Integer id) {
		Optional<Turno> turnoEncontrado = turnos.stream().filter(e -> e.getNumeroTurno() == id) 
				.findFirst();
		turnoEncontrado.ifPresent(turnos::remove); 
	}

	@Override
	public void agregar(Turno dato) {
		turnos.add(dato); 
	}

	@Override
	public List<Turno> obtenerLista() {
		return new ArrayList<>(turnos); 
	}

	public int generarNumeroTurno() {
		return turnos.stream().mapToInt(Turno::getNumeroTurno) 
				.max() 
				.orElse(0) + 1;
	}

	public void cargarTurnos() throws IOException, ClassNotFoundException {
		List<TurnoDTO> listaDTO = binariosFile.leerArchivoTurnos(); 
		turnos = binariosFile.convertirListaTurnos(listaDTO); 
		System.out.println("Turnos cargados: " + turnos.size());
	}

	private List<TurnoDTO> convertirAListaDTO(List<Turno> turnos) { 
		List<TurnoDTO> listaDTO = new ArrayList<>();
		for (Turno turno : turnos) {
			listaDTO.add(new TurnoDTO(turno.getNumeroTurno(), turno.getDocumentoPaciente(), turno.getEstado())); // Crear
																													// DTO
		}
		return listaDTO; 
	}

	
	public void eliminarTodos() {
		turnos.clear(); 
		System.out.println("Todos los turnos han sido eliminados.");
	}
}
