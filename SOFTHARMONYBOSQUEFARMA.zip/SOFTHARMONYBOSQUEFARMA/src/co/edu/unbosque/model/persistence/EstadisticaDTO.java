package co.edu.unbosque.model.persistence;

public class EstadisticaDTO {
	private int totalTurnosAtendidos;
	private int totalTurnosPendientes;
	private int totalMedicamentosExpedidos;
	private double totalVentas;

	public EstadisticaDTO(int totalTurnosAtendidos, int totalTurnosPendientes, int totalMedicamentosExpedidos) {
		this.totalTurnosAtendidos = totalTurnosAtendidos;
		this.totalTurnosPendientes = totalTurnosPendientes;
		this.totalMedicamentosExpedidos = totalMedicamentosExpedidos;

	}

	// Getters y Setters
	public int getTotalTurnosAtendidos() {
		return totalTurnosAtendidos;
	}

	public void setTotalTurnosAtendidos(int totalTurnosAtendidos) {
		this.totalTurnosAtendidos = totalTurnosAtendidos;
	}

	public int getTotalTurnosPendientes() {
		return totalTurnosPendientes;
	}

	public void setTotalTurnosPendientes(int totalTurnosPendientes) {
		this.totalTurnosPendientes = totalTurnosPendientes;
	}

	public int getTotalMedicamentosExpedidos() {
		return totalMedicamentosExpedidos;
	}

	public void setTotalMedicamentosExpedidos(int totalMedicamentosExpedidos) {
		this.totalMedicamentosExpedidos = totalMedicamentosExpedidos;
	}

	@Override
	public String toString() {
		return "Estadísticas:\n" + "Total Turnos Atendidos: " + totalTurnosAtendidos + "\n"
				+ "Total Turnos Pendientes: " + totalTurnosPendientes + "\n" + "Total Medicamentos Expedidos: "
				+ totalMedicamentosExpedidos + "\n" + "Total Ventas: $" + totalVentas;
	}
}