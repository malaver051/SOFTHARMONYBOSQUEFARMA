package co.edu.unbosque.model.persistence;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import co.edu.unbosque.model.Inventario;
import co.edu.unbosque.model.Turno;
import co.edu.unbosque.model.Expendio;

public class binariosFile {

    private final String rutaFun = "./data/funcionarios.out";
    private final String rutaInv = "./data/inventario.dat";
    private final String rutaTurnos = "./data/turnos.out"; 
    private final String rutaExpendios = "./data/expendios.out"; 

    private List<FuncionarioDTO> listaFun = new ArrayList<>();
    private List<InventarioDTO> listaInv = new ArrayList<>();
    private List<TurnoDTO> listaTurnos = new ArrayList<>(); 
    private List<ExpendioDTO> listaExpendios = new ArrayList<>(); 

    public binariosFile() {
        leerArchivoFuncionarios();
        leerArchivoInventario();
        leerArchivoTurnos(); 
        leerArchivoExpendios(); 
    }

    private <T> void escribirArchivo(String ruta, List<T> lista) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(lista);
            System.out.println("Archivo escrito correctamente en: " + ruta);
        } catch (IOException e) {
            throw new IOException("Error al escribir el archivo en " + ruta + ": " + e.getMessage(), e);
        }
    }

    public void escribirArchivoFuncionarios() throws IOException {
        escribirArchivo(rutaFun, listaFun);
    }

    public void escribirArchivoInventario() throws IOException {
        escribirArchivo(rutaInv, listaInv);
    }

    public void escribirArchivoTurnos() throws IOException {
        escribirArchivo(rutaTurnos, listaTurnos);
    }

    public void escribirArchivoExpendios() throws IOException {
        escribirArchivo(rutaExpendios, listaExpendios);
    }

    @SuppressWarnings("unchecked")
    private <T> List<T> leerArchivo(String ruta) {
        File file = new File(ruta);
        if (!file.exists()) {
            System.err.println("Archivo no encontrado: " + ruta);
            return new ArrayList<>();
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            List<T> lista = (List<T>) ois.readObject();
            System.out.println("Archivo leído correctamente: " + ruta);
            return lista;
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al leer el archivo en " + ruta + ": " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public List<FuncionarioDTO> leerArchivoFuncionarios() {
        listaFun = leerArchivo(rutaFun);
        return listaFun;
    }

    public List<InventarioDTO> leerArchivoInventario() {
        listaInv = leerArchivo(rutaInv);
        return listaInv;
    }

    public List<TurnoDTO> leerArchivoTurnos() {
        listaTurnos = leerArchivo(rutaTurnos);
        return listaTurnos;
    }

    public List<ExpendioDTO> leerArchivoExpendios() {
        listaExpendios = leerArchivo(rutaExpendios);
        return listaExpendios;
    }

    public List<Turno> convertirListaTurnos(List<TurnoDTO> listaDTO) {
        List<Turno> listaTurnos = new ArrayList<>();
        for (TurnoDTO dto : listaDTO) {
            listaTurnos.add(new Turno(dto.getNumeroTurno(), dto.getDocumentoPaciente(), dto.getEstado()));
        }
        return listaTurnos;
    }

    public List<Inventario> convertirListaInventario(List<InventarioDTO> listaDTO) {
        List<Inventario> listaInventario = new ArrayList<>();
        for (InventarioDTO dto : listaDTO) {
            listaInventario.add(new Inventario(dto.getNumMedicamento(), dto.getNombreMedicamento(), (int) dto.getCodigoMedicamento()));
        }
        return listaInventario;
    }

    public List<Expendio> convertirListaExpendios(List<ExpendioDTO> listaDTO) {
        List<Expendio> listaExpendios = new ArrayList<>();
        for (ExpendioDTO dto : listaDTO) {
            listaExpendios.add(new Expendio(dto.getNombre())); 
        }
        return listaExpendios;
    }

    public List<FuncionarioDTO> getListaFun() {
        return new ArrayList<>(listaFun); 
    }

    public void setListaFun(List<FuncionarioDTO> listaFun) {
        if (listaFun != null) {
            this.listaFun = new ArrayList<>(listaFun);
        }
    }

    public List<InventarioDTO> getListaInv() {
        return new ArrayList<>(listaInv);
    }

    public void setListaInv(List<InventarioDTO> listaInv) {
        if (listaInv != null) {
            this.listaInv = new ArrayList<>(listaInv);
        }
    }

    public List<TurnoDTO> getListaTurnos() {
        return new ArrayList<>(listaTurnos);
    }

    public void setListaTurnos(List<TurnoDTO> listaTurnos) {
        if (listaTurnos != null) {
            this.listaTurnos = new ArrayList<>(listaTurnos);
        }
    }

    public List<ExpendioDTO> getListaExpendios() {
        return new ArrayList<>(listaExpendios);
    }

    public void setListaExpendios(List<ExpendioDTO> listaExpendios) {
        if (listaExpendios != null) {
            this.listaExpendios = new ArrayList<>(listaExpendios);
        }
    }
}