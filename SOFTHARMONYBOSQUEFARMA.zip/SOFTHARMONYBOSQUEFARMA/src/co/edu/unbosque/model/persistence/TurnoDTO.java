package co.edu.unbosque.model.persistence;

import java.io.Serializable;

public class TurnoDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	private int numeroTurno;
	private String documentoPaciente;
	private String estado;

	public TurnoDTO(int numeroTurno, String documentoPaciente, String estado) {
		this.numeroTurno = numeroTurno;
		this.documentoPaciente = documentoPaciente;
		setEstado(estado); 
	}

	
	public int getNumeroTurno() {
		return numeroTurno;
	}

	public void setNumeroTurno(int numeroTurno) {
		this.numeroTurno = numeroTurno;
	}

	public String getDocumentoPaciente() {
		return documentoPaciente;
	}

	public void setDocumentoPaciente(String documentoPaciente) {
		if (documentoPaciente == null || documentoPaciente.isEmpty()) {
			throw new IllegalArgumentException("El documento del paciente no puede estar vacío.");
		}
		this.documentoPaciente = documentoPaciente;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		if (estado == null || estado.isEmpty()) {
			throw new IllegalArgumentException("El estado no puede estar vacío.");
		}
		this.estado = estado;
	}

	
	@Override
	public String toString() {
		return "TurnoDTO{" + "numeroTurno=" + numeroTurno + ", documentoPaciente='" + documentoPaciente + '\''
				+ ", estado='" + estado + '\'' + '}';
	}
}
