package co.edu.unbosque.model.persistence;

import co.edu.unbosque.model.Funcionario;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class FuncionarioDAO implements CRUD<Funcionario, String> {

    private List<Funcionario> funcionarios;
    private binariosFile bf;
    private final String SERIAL_NAME = "./data/funcionarios.out";

    public FuncionarioDAO() {
        funcionarios = new ArrayList<>();
        bf = new binariosFile();
        File archivo = new File(SERIAL_NAME);
        
        try {
            if (!archivo.exists()) {
                archivo.createNewFile();
                System.out.println("Archivo de funcionarios creado.");
            } else {
                
                List<FuncionarioDTO> dtoList = bf.leerArchivoFuncionarios();
                funcionarios = convertirAListaFuncionario(dtoList);
                System.out.println("Datos de funcionarios cargados: " + funcionarios.size());
            }
        } catch (IOException e) {
            System.err.println("Error al crear o leer el archivo de funcionarios: " + e.getMessage());
        }
    }

    private Funcionario convertirADTO(FuncionarioDTO dto) {
        return new Funcionario(dto.getNombre(), dto.getCedula(), dto.getContraseña(), dto.getCorreo());
    }

    private List<Funcionario> convertirAListaFuncionario(List<FuncionarioDTO> dtoList) {
        List<Funcionario> funcionarios = new ArrayList<>();
        for (FuncionarioDTO dto : dtoList) {
            funcionarios.add(convertirADTO(dto));
        }
        return funcionarios;
    }

    @Override
    public void guardar() throws IOException {
        bf.setListaFun(convertirAListaDTO(funcionarios));
        bf.escribirArchivoFuncionarios();
        System.out.println("Datos de funcionarios guardados.");
    }

    @Override
    public void actualizar(Funcionario dato, String cedula) {
        Optional<Funcionario> funcionarioOpt = buscarPorCedula(cedula);
        if (funcionarioOpt.isPresent()) {
            Funcionario funcionarioExistente = funcionarioOpt.get();
            funcionarioExistente.setNombre(dato.getNombre());
            funcionarioExistente.setContraseña(dato.getContraseña());
            funcionarioExistente.setCorreo(dato.getCorreo());
            try {
                guardar(); 
            } catch (IOException e) {
                System.err.println("Error al guardar los cambios después de actualizar el funcionario: " + e.getMessage());
            }
        } else {
            System.err.println("Funcionario con cédula " + cedula + " no encontrado para actualizar.");
        }
    }

    @Override
    public void eliminar(String cedula) {
        Funcionario funcionarioAEliminar = null;

        
        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getCedula().equals(cedula)) {
                funcionarioAEliminar = funcionario;
                break;
            }
        }

        
        if (funcionarioAEliminar != null) {
            funcionarios.remove(funcionarioAEliminar);
            try {
                guardar(); 
            } catch (IOException e) {
                System.err.println("Error al guardar los cambios después de eliminar el funcionario: " + e.getMessage());
            }
        } else {
            System.err.println("Funcionario con cédula " + cedula + " no encontrado.");
        }
    }

    @Override
    public void agregar(Funcionario dato) {
        if (!existeFuncionario(dato.getCedula())) {
            funcionarios.add(dato);
            try {
                guardar(); 
                System.out.println("Funcionario agregado: " + dato.getCedula());
            } catch (IOException e) {
                System.err.println("Error al guardar los cambios después de agregar el funcionario: " + e.getMessage());
            }
        } else {
            System.err.println("Funcionario con cédula " + dato.getCedula() + " ya existe.");
        }
    }

    @Override
    public List<Funcionario> obtenerLista() {
        return new ArrayList<>(funcionarios); 
    }

    public Optional<Funcionario> buscarPorCedula(String cedula) {
        return funcionarios.stream().filter(e -> e.getCedula().equals(cedula)).findFirst();
    }

    
    public List<Funcionario> buscarPorNombre(String nombre) {
        List<Funcionario> encontrados = new ArrayList<>();
        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                encontrados.add(funcionario);
            }
        }
        return encontrados;
    }

    private boolean existeFuncionario(String cedula) {
        return funcionarios.stream().anyMatch(e -> e.getCedula().equals(cedula));
    }

    private List<FuncionarioDTO> convertirAListaDTO(List<Funcionario> funcionarios) {
        List<FuncionarioDTO> listaDTO = new ArrayList<>();
        for (Funcionario func : funcionarios) {
            listaDTO.add(new FuncionarioDTO(func.getNombre(), func.getCedula(), func.getContraseña(), func.getCorreo()));
        }
        return listaDTO;
    }
}
