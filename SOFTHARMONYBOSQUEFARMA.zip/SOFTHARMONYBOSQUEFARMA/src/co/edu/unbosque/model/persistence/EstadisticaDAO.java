package co.edu.unbosque.model.persistence;

import java.util.List;

import co.edu.unbosque.model.Inventario;
import co.edu.unbosque.model.Turno;

public class EstadisticaDAO {
    private List<Turno> turnos; 
    private List<Inventario> inventario; 

    public EstadisticaDAO(List<Turno> turnos, List<Inventario> inventario) {
        this.turnos = turnos;
        this.inventario = inventario;
    }

    public EstadisticaDTO obtenerEstadisticas() {
        int totalTurnosAtendidos = (int) turnos.stream().filter(t -> t.getEstado().equals("atendido")).count();
        int totalTurnosPendientes = (int) turnos.stream().filter(t -> t.getEstado().equals("por atender")).count();
        
        
        int totalMedicamentosExpedidos = inventario.stream()
            .mapToInt(Inventario::getCantidad) 
            .sum();
        return new EstadisticaDTO(totalTurnosAtendidos, totalTurnosPendientes, totalMedicamentosExpedidos);
    }

    
}