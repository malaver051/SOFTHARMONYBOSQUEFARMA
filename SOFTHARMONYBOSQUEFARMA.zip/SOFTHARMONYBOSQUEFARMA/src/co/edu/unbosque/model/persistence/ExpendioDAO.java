package co.edu.unbosque.model.persistence;

import co.edu.unbosque.model.Expendio;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ExpendioDAO implements CRUD<Expendio, String> {

    private List<Expendio> expendios;
    private binariosFile bf; 
    private final String SERIAL_NAME = "./data/expendios.out"; 
    public ExpendioDAO() {
        expendios = new ArrayList<>();
        bf = new binariosFile(); 
        File archivo = new File(SERIAL_NAME);
        try {
            if (!archivo.exists()) {
                archivo.createNewFile();
                System.out.println("Archivo de expendios creado.");
            } else {
                
                List<ExpendioDTO> datosCargadosDTO = bf.leerArchivoExpendios(); 
                List<Expendio> datosCargados = bf.convertirListaExpendios(datosCargadosDTO); 
                expendios.addAll(datosCargados);
                System.out.println("Datos de expendios cargados: " + expendios.size());
            }
        } catch (IOException e) {
            System.err.println("Error al crear o leer el archivo de expendios: " + e.getMessage());
        }
    }

    @Override
    public void guardar() throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(SERIAL_NAME))) {
            List<ExpendioDTO> listaDTO = convertirAListaDTO(expendios);
            oos.writeObject(listaDTO); 
            System.out.println("Expendios guardados correctamente.");
        } catch (IOException e) {
            throw new IOException("Error al guardar los expendios: " + e.getMessage(), e);
        }
    }

    @Override
    public void actualizar(Expendio dato, String nombre) {
        Optional<Expendio> expendioOpt = buscarPorNombre(nombre);
        if (expendioOpt.isPresent()) {
            
            int index = expendios.indexOf(expendioOpt.get());
            expendios.set(index, dato); 
            try {
                guardar(); 
                System.out.println("Expendio actualizado: " + dato.getNombre());
            } catch (IOException e) {
                System.err.println("Error al guardar los cambios después de actualizar el expendio: " + e.getMessage());
            }
        } else {
            throw new IllegalArgumentException("Expendio con nombre " + nombre + " no encontrado.");
        }
    }

    @Override
    public void eliminar(String nombre) {
        Optional<Expendio> expendioOpt = buscarPorNombre(nombre);
        if (expendioOpt.isPresent()) {
            expendios.remove(expendioOpt.get());
            try {
                guardar(); 
                System.out.println("Expendio eliminado: " + nombre);
            } catch (IOException e) {
                System.err.println("Error al guardar los cambios después de eliminar el expendio: " + e.getMessage());
            }
        } else {
            System.err.println("Expendio con nombre " + nombre + " no encontrado.");
        }
    }

    @Override
    public void agregar(Expendio dato) {
        if (!existeExpendio(dato.getNombre())) {
            expendios.add(dato);
            System.out.println("Expendio agregado: " + dato.getNombre());
            try {
                guardar(); 
            } catch (IOException e) {
                System.err.println("Error al guardar los cambios después de agregar el expendio: " + e.getMessage());
            }
        } else {
            throw new IllegalArgumentException("Expendio con nombre " + dato.getNombre() + " ya existe.");
        }
    }

    @Override
    public List<Expendio> obtenerLista() {
        return new ArrayList<>(expendios); 
    }

    public Optional<Expendio> buscarPorNombre(String nombre) {
        return expendios.stream().filter(e -> e.getNombre().equals(nombre)).findFirst();
    }

    private boolean existeExpendio(String nombre) {
        return expendios.stream().anyMatch(e -> e.getNombre().equals(nombre));
    }

    
    private List<ExpendioDTO> convertirAListaDTO(List<Expendio> expendios) {
        List<ExpendioDTO> listaDTO = new ArrayList<>();
        for (Expendio exp : expendios) {
            listaDTO.add(new ExpendioDTO(exp.getNombre())); 
        }
        return listaDTO;
    }
}
