package co.edu.unbosque.model.persistence;

import java.io.Serializable;

public class InventarioDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private int numMedicamento;
	private String nombreMedicamento;
	private double codigoMedicamento;

	public InventarioDTO(int numMedicamento, String nombreMedicamento, double codigoMedicamento) {
		this.numMedicamento = numMedicamento;
		this.nombreMedicamento = nombreMedicamento;
		this.codigoMedicamento = codigoMedicamento;
	}

	public int getNumMedicamento() {
		return numMedicamento;
	}

	public void setNumMedicamento(int numMedicamento) {
		this.numMedicamento = numMedicamento;
	}

	public String getNombreMedicamento() {
		return nombreMedicamento;
	}

	public void setNombreMedicamento(String nombreMedicamento) {
		this.nombreMedicamento = nombreMedicamento;
	}

	public double getCodigoMedicamento() {
		return codigoMedicamento;
	}

	public void setCodigoMedicamento(double codigoMedicamento) {
		this.codigoMedicamento = codigoMedicamento;
	}
}
