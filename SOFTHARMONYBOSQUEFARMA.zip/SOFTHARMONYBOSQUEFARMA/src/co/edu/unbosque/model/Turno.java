package co.edu.unbosque.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import co.edu.unbosque.model.persistence.TurnoDTO;

public class Turno implements Serializable {
	private static final long serialVersionUID = 1L;
	private int numeroTurno;
	private String documentoPaciente;
	private String estado;

	public static final String ESTADO_POR_ATENDER = "por atender";
	public static final String ESTADO_ATENDIDO = "atendido";
	public static final String ESTADO_CANCELADO = "cancelado";

	public Turno(int numeroTurno, String documentoPaciente, String estado) {
		this.numeroTurno = numeroTurno;
		this.documentoPaciente = documentoPaciente;
		setEstado(estado);
	}

	// Getters y Setters
	public int getNumeroTurno() {
		return numeroTurno;
	}

	public void setNumeroTurno(int numeroTurno) {
		this.numeroTurno = numeroTurno;
	}

	public String getDocumentoPaciente() {
		return documentoPaciente;
	}

	public void setDocumentoPaciente(String documentoPaciente) {
		
		if (documentoPaciente == null || documentoPaciente.isEmpty()) {
			throw new IllegalArgumentException("El documento del paciente no puede estar vacío.");
		}
		this.documentoPaciente = documentoPaciente;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		
		if (estado.equals(ESTADO_POR_ATENDER) || estado.equals(ESTADO_ATENDIDO) || estado.equals(ESTADO_CANCELADO)) {
			this.estado = estado;
		} else {
			throw new IllegalArgumentException("Estado no válido: " + estado);
		}
	}

	public List<Turno> convertirListaTurnos(List<TurnoDTO> listaDTO) {
		List<Turno> listaTurnos = new ArrayList<>();
		for (TurnoDTO dto : listaDTO) {
			listaTurnos.add(new Turno(dto.getNumeroTurno(), dto.getDocumentoPaciente(), dto.getEstado()));
		}
		System.out.println("Lista de turnos convertida: " + listaTurnos.size() + " turnos.");
		return listaTurnos;
	}

	
	public String mostrarInformacion() {
		return "Turno #" + numeroTurno + " - Paciente: " + documentoPaciente + " - Estado: " + estado;
	}

	
	public void cambiarEstado(String nuevoEstado) {
		setEstado(nuevoEstado);
	}

	@Override
	public String toString() {
		return mostrarInformacion();
	}
}
