package co.edu.unbosque.model;

public class Expendio {
	private String nombre;

	public Expendio() {

	}

	public Expendio(String nombre) {
		setNombre(nombre); // Usar el setter para validar

	}

	
	public String getNombre() {
		return nombre;
	}

	// Setter para nombre con validación
	public void setNombre(String nombre) {
		if (nombre == null || nombre.trim().isEmpty()) {
			throw new IllegalArgumentException("El nombre no puede ser nulo o vacío.");
		}
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Expendio{" + "nombre='" + nombre + '\'' + '}';
	}

}