package co.edu.unbosque.model;

import java.io.Serializable;

public class Inventario implements Serializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private String nombreMedicamento;
    private int cantidad;
   
   
    public Inventario(int id, String nombreMedicamento, int cantidad) {
        this.id = id;
        this.nombreMedicamento = nombreMedicamento;
        this.cantidad = cantidad;
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreMedicamento() {
        return nombreMedicamento;
    }

    public void setNombreMedicamento(String nombreMedicamento) {
        this.nombreMedicamento = nombreMedicamento;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

  

    // Método para restar la cantidad del medicamento
    public boolean restarCantidad(int cantidadSolicitada) {
        if (this.cantidad >= cantidadSolicitada) {
            this.cantidad -= cantidadSolicitada;
            return true; // Indica que la resta fue exitosa
        } else {
            return false; // No hay suficiente stock
        }
    }
}
