package co.edu.unbosque.model;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import co.edu.unbosque.model.persistence.binariosFile;
import co.edu.unbosque.model.persistence.CRUD;

public class Facade {
    private CRUD<Funcionario, String> fDAO; 
    private CRUD<Inventario, Integer> iDAO;
    private binariosFile binariosFile; 

    // Constructor 
    public Facade(CRUD<Funcionario, String> fDAO, CRUD<Inventario, Integer> iDAO, binariosFile binariosFile) {
        this.fDAO = fDAO; 
        this.iDAO = iDAO; 
        this.binariosFile = binariosFile; 
    }

    
    public void agregarFuncionario(Funcionario funcionario) throws IOException {
        fDAO.agregar(funcionario); 
        guardar(fDAO); 
    }

    public void eliminarFuncionario(String cedula) throws IOException {
        fDAO.eliminar(cedula);
        guardar(fDAO); 
    }

    public List<Funcionario> obtenerListaFuncionarios() {
        return fDAO.obtenerLista(); 
    }

    public void guardarFuncionarios() throws IOException {
        guardar(fDAO);
    }

   
    public void agregarInventario(Inventario inventario) throws IOException {
        iDAO.agregar(inventario);
        guardar(iDAO); 
    }

    public void actualizarInventario(Inventario inventario, Integer id) throws IOException {
        iDAO.actualizar(inventario, id);
        guardar(iDAO); 
    }

    public void eliminarInventario(Integer id) throws IOException {
        iDAO.eliminar(id);
        guardar(iDAO); 
    }

    public Optional<Inventario> buscarInventarioPorId(Integer id) {
        if (id == null) {
            return Optional.empty(); 
        }

        return iDAO.obtenerLista().stream()
                .filter(inventario -> inventario != null && id.equals(inventario.getId())) // Cambiar el orden de la comparación
                .findFirst();
    }

    public List<Inventario> obtenerListaInventarios() {
        return iDAO.obtenerLista(); 
    }

    public void guardarInventarios() throws IOException {
        guardar(iDAO);
    }

    // Método genérico para guardar los cambios de cualquier DAO
    private <T, ID> void guardar(CRUD<T, ID> dao) throws IOException {
        dao.guardar(); 
    }
}
