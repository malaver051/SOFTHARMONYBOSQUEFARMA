package co.edu.unbosque.util.exception;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Clase que proporciona métodos para verificar condiciones y lanzar excepciones personalizadas.
 */
public class ExceptionChecker {
    public static void verifyNegativeNumber(int number) throws NegativeNumberException {
        if (number < 0) {
            throw new NegativeNumberException();
        }
    }

    public static void verifyName(String name) throws NameNotValidException {
        Pattern p = Pattern.compile("[^\\wáéíóú ]");
        Matcher n = p.matcher(name);
        if (n.find()) {
            throw new NameNotValidException();
        }
    }

    public static void verifySymbol(String chain) throws NameNotValidException {
        Pattern p = Pattern.compile("[^a-zA-Z0-9 áéíóú]");
        Matcher m = p.matcher(chain);
        if (m.find()) {
            throw new NameNotValidException();
        }
    }

    public static void verifyMail(String email) throws ValideMailException {
        Pattern p = Pattern.compile("^[\\w-\\.]+@[\\w-]+\\.[a-zA-Z]{2,}$");
        Matcher m = p.matcher(email);
        if (!m.matches()) {
            throw new ValideMailException();
        }
    }

    public static void verifyStockAvailability(int num) throws StockAvailabilityException {
        if (num <= 0) {
            throw new StockAvailabilityException();
        }
    }
}