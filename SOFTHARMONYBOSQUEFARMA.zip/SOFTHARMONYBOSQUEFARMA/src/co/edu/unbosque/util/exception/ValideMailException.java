package co.edu.unbosque.util.exception;

/**
 * Excepción personalizada que se lanza cuando un correo electrónico no es válido.
 */
public class ValideMailException extends Exception {
    private static final long serialVersionUID = 1L;

    public ValideMailException() {
        super("El correo no es válido.");
    }

    public ValideMailException(String message) {
        super(message);
    }
}