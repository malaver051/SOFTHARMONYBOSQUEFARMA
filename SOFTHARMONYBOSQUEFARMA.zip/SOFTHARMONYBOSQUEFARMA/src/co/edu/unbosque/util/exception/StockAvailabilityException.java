package co.edu.unbosque.util.exception;

/**
 * Excepción personalizada que se lanza cuando no hay suficiente stock de un medicamento.
 */
public class StockAvailabilityException extends Exception {
    private static final long serialVersionUID = 1L;

    public StockAvailabilityException() {
        super("No hay suficiente medicamento en stock.");
    }
    public StockAvailabilityException(String message) {
        super(message);
    }
}