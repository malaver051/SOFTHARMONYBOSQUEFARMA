package co.edu.unbosque.util.exception;

/**
 * Excepción personalizada que se lanza cuando un nombre no es válido.
 */
public class NameNotValidException extends Exception {
    private static final long serialVersionUID = 1L;
    public NameNotValidException() {
        super("No se aceptan símbolos diferentes a las letras del abecedario");
    }

    public NameNotValidException(String message) {
        super(message);
    }
}