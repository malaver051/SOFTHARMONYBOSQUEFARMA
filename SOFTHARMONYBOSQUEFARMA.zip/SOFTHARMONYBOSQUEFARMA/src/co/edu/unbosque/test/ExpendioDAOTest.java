package co.edu.unbosque.test;

import co.edu.unbosque.model.Expendio;
import co.edu.unbosque.model.persistence.ExpendioDAO;
import junit.framework.TestCase;
import java.util.List;
import java.util.Optional;

public class ExpendioDAOTest extends TestCase {

    private ExpendioDAO expendioDAO;

    protected void setUp() throws Exception {
        expendioDAO = new ExpendioDAO();
    }



    public void testAgregarExpendio() {
        Expendio expendio = new Expendio("Expendio 1");
        expendioDAO.agregar(expendio);
        
        Optional<Expendio> resultado = expendioDAO.buscarPorNombre("Expendio 1");
        assertTrue("Expendio debería ser encontrado después de agregarlo", resultado.isPresent());
        assertEquals("Nombre del expendio debería ser 'Expendio 1'", "Expendio 1", resultado.get().getNombre());
    }	

    public void testObtenerLista() {
        Expendio expendio1 = new Expendio("Expendio 1");
        Expendio expendio2 = new Expendio("Expendio 2");
        
        expendioDAO.agregar(expendio1);
        expendioDAO.agregar(expendio2);
        
        List<Expendio> listaExpendios = expendioDAO.obtenerLista();
        assertEquals("Deberían haber 2 expendios en la lista", 2, listaExpendios.size());
    }

    public void testActualizarExpendio() {
        Expendio expendioOriginal = new Expendio("Expendio Original");
        expendioDAO.agregar(expendioOriginal);
        
        Expendio expendioActualizado = new Expendio("Expendio Actualizado");
        expendioDAO.actualizar(expendioActualizado, "Expendio Original");
        
        Optional<Expendio> resultado = expendioDAO.buscarPorNombre("Expendio Actualizado");
        assertTrue("Expendio debería haber sido actualizado", resultado.isPresent());
        assertEquals("Nombre del expendio debería ser 'Expendio Actualizado'", "Expendio Actualizado", resultado.get().getNombre());
    }

    public void testEliminarExpendio() {
        Expendio expendio = new Expendio("Expendio a eliminar");
        expendioDAO.agregar(expendio);
        
        expendioDAO.eliminar("Expendio a eliminar");
        
        Optional<Expendio> resultado = expendioDAO.buscarPorNombre("Expendio a eliminar");
        assertFalse("Expendio no debería ser encontrado después de eliminarlo", resultado.isPresent());
    }
    protected void tearDown() throws Exception {
       System.out.println("Finalizando");
    }
}
