package co.edu.unbosque.test;

import co.edu.unbosque.model.Funcionario;
import co.edu.unbosque.model.persistence.FuncionarioDAO;
import junit.framework.TestCase;
import java.util.List;
import java.util.Optional;

public class FuncionarioDAOTest extends TestCase {
	private FuncionarioDAO funcionarioDAO;
    private Funcionario funcionario1;
    private Funcionario funcionario2;

	protected void setUp() throws Exception {
		super.setUp();
		
		funcionarioDAO = new FuncionarioDAO();

       
        funcionario1 = new Funcionario("Juan Perez", "12345", "pass123", "juan@correo.com");
        funcionario2 = new Funcionario("Maria Gomez", "67890", "pass456", "maria@correo.com");

       
        funcionarioDAO.obtenerLista().clear();
        funcionarioDAO.agregar(funcionario1);
        funcionarioDAO.agregar(funcionario2);
	}
	 public void testAgregarFuncionario() {
	        Funcionario nuevoFuncionario = new Funcionario("Pedro Lopez", "54321", "pass789", "pedro@correo.com");
	        
	        funcionarioDAO.agregar(nuevoFuncionario);
	        assertTrue(funcionarioDAO.buscarPorCedula("54321").isPresent());
	    }

	    public void testEliminarFuncionario() {
	        funcionarioDAO.eliminar("12345");
	        Optional<Funcionario> eliminado = funcionarioDAO.buscarPorCedula("12345");
	        
	        assertFalse(eliminado.isPresent());
	    }

	    public void testBuscarPorCedula() {
	        Optional<Funcionario> encontrado = funcionarioDAO.buscarPorCedula("67890");
	        
	        assertTrue(encontrado.isPresent());
	        assertEquals("Maria Gomez", encontrado.get().getNombre());
	    }

	    public void testBuscarPorNombre() {
	        List<Funcionario> resultados = funcionarioDAO.buscarPorNombre("Maria");
	        
	        assertEquals(1, resultados.size());
	        assertEquals("Maria Gomez", resultados.get(0).getNombre());
	    }

	protected void tearDown() throws Exception {
		System.out.println("finalizando");
	}

}
